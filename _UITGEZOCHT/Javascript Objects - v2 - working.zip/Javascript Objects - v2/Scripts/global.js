var pagedata = 
{
	Pages: 
	[
		{
			PageId: '01',
			PageTitle: 'Pagine 1',
			PageContent: 'Tekst pagina 1'
			
		},
		{
			PageId: '02',
			PageTitle: 'Pagine 2',
			PageContent: 'Tekst pagina 2'
		},
		{
			PageId: '03',
			PageTitle: 'Pagine 3',
			PageContent: 'Tekst pagina 3'
		}
	]		
};

	

// ------------------------------------------------------------------------------------------------
// Document Ready
// ------------------------------------------------------------------------------------------------
$(function() {
		   
   	// Wensen:
	// html in page uit template halen
	// content per pagina pushen in template html
	// afwijkingen per pagina mogelijk maken, hoe? Misschien door overerving van basis page en toevoegen/ overrulen standaard functionaliteit. Dus prototype?
	// history/ BBQ plugin eraan koppelen

	// basic init
	page.init();
	// Overide with custom params
	//page.init({ 'prevText' : 'De vorige pagina' });
	
});

