var data = 
{
	Page: 
	[
		{
			PageId: 1,
			PageTitle: 'Pagine 1',
			PageContent: 'Inhoud van pagina 1'
		},
		{
			PageId: 2,
			PageTitle: 'Pagine 2',
			PageContent: 'Inhoud van pagina 1'
		},
		{
			PageId: 3,
			PageTitle: 'Pagine 3',
			PageContent: 'Inhoud van pagina 3'
		}
	]		
};


// ------------------------------------------------------------------------------------------------
// Document Ready
// ------------------------------------------------------------------------------------------------
$(function() {
		   
   	// Wensen:
	// html in page uit template halen
	// content per pagina pushen in template html
	// afwijkingen per pagina mogelijk maken, hoe? Misschien door overerving van basis page en toevoegen/ overrulen standaard functionaliteit. Dus prototype?

	// Load html template
	var template = $('#page-template').html();
	console.log(template);	


	// basic init
	page.init();
	// Overide with custom params
	//page.init({ 'prevText' : 'De vorige' });
	
	

		

	//var html = Mustache.to_html(template, data);
	//	$("body").html(html);

	

	
	
});

