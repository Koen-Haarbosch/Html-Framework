//http://www.rebeccamurphey.com/jsmag/object-literal/
//http://www.rebeccamurphey.com/jsmag/object-literal/js/object-literal.js

var page = {
    'config' : { 
		'container' : $('#wrapper'),
		'prevText' : 'Vorige',
		'nextText' : 'Volgende',
		'contentUrl' : '/content/test.xml'
	},

    'init' : function(config) {
        if (config && typeof(config) == 'object') {
			$.extend(page.config, config);
		}

		page.$container = page.config.container;

		page.$sections = page.$container.
			find('div.page'); 
		
		// replace these with template html
		// and fill template html with dynamic content
		/*
        page.$content = $('<h2/>').
			text('Titel').
			appendTo(page.$sections);
		page.$content = $('<p/>').
			text('Korte tekst').
			appendTo(page.$sections);
		page.$content = $('<div/>').
			attr('class','page-nav').
			appendTo(page.$sections);
		*/



		page.buildPageNav(page.$sections);
		
		//page.$sections.find('div.page-nav a:first').click();
		$('.page:first-child').addClass('current');
		
		page.initialized = true;
		
    },
	
	'buildPageNav' : function($sections) {

		$sections.each(function() {

			var $section = $(this);		
			var $pagenav = $section.find('div.page-nav');
			// Build the Previous link
			$('<span/>').
				text(page.config.prevText).
				appendTo($pagenav).
				addClass('prev').
				data('section', $section).
				click(page.showSection);
			// Build the next link
			$('<span/>').
				text(page.config.nextText).
				appendTo($pagenav).
				addClass('next').
				data('section', $section).
				click(page.showSection);
				
		});

	},

	'showSection' : function() { 
		var $li = $(this);

		var $section = $li.data('section');
		// Set click behaviour for previous link
		if($li.hasClass('prev')){
			$section.prev().addClass('current').
			siblings().removeClass('current');		
		}
		// Set click behaviour for next link
		if($li.hasClass('next')){
			$section.next().addClass('current').
			siblings().removeClass('current');		
		}
		

	},

	'showContentItem' : function() {

		var $li = $(this);
		
		$li.addClass('current').
			siblings().removeClass('current');

		var $item = $li.data('item');

		page.$content.html($item.html());

	}

	
};
